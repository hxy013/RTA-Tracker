import torch
import torch.nn as nn
from torch.nn import functional as F
from torch.nn.parameter import Parameter

from siamban.models.init_weight import kaiming_init

torch_ver = torch.__version__[:3]

class BasicConv(nn.Module):
    def __init__(
        self,
        in_planes,
        out_planes,
        kernel_size,
        stride=1,
        padding=0,
        dilation=1,
        groups=1,
        relu=True,
        bn=True,
        bias=False,
    ):
        super(BasicConv, self).__init__()
        self.out_channels = out_planes
        self.conv = nn.Conv2d(
            in_planes,
            out_planes,
            kernel_size=kernel_size,
            stride=stride,
            padding=padding,
            dilation=dilation,
            groups=groups,
            bias=bias,
        )
        self.bn = (
            nn.BatchNorm2d(out_planes, eps=1e-5, momentum=0.01, affine=True)
            if bn
            else None
        )
        self.relu = nn.ReLU() if relu else None

    def forward(self, x):
        x = self.conv(x)
        if self.bn is not None:
            x = self.bn(x)
        if self.relu is not None:
            x = self.relu(x)
        return x


class ZPool(nn.Module):
    def forward(self, x):
        return torch.cat(
            (torch.max(x, 1)[0].unsqueeze(1), torch.mean(x, 1).unsqueeze(1)), dim=1
        )


class AttentionGate(nn.Module):
    def __init__(self):
        super(AttentionGate, self).__init__()
        kernel_size = 7
        self.compress = ZPool()
        self.conv = BasicConv(
            2, 1, kernel_size, stride=1, padding=(kernel_size - 1) // 2, relu=False
        )

    def forward(self, x):
        x_compress = self.compress(x)
        x_out = self.conv(x_compress)
        scale = torch.sigmoid_(x_out)
        return x * scale


class TripletAttention(nn.Module):
    def __init__(self, no_spatial=False):
        super(TripletAttention, self).__init__()
        self.cw = AttentionGate()
        self.hc = AttentionGate()
        self.no_spatial = no_spatial
        if not no_spatial:
            self.hw = AttentionGate()
        self.gamma = nn.Parameter(torch.zeros(1))

    def forward(self, x):
        x_perm1 = x.permute(0, 2, 1, 3).contiguous()
        x_out1 = self.cw(x_perm1)
        x_out11 = x_out1.permute(0, 2, 1, 3).contiguous()
        x_perm2 = x.permute(0, 3, 2, 1).contiguous()
        x_out2 = self.hc(x_perm2)
        x_out21 = x_out2.permute(0, 3, 2, 1).contiguous()
        if not self.no_spatial:
            x_out = self.hw(x)
            x_out = 1 / 3 * (x_out + x_out11 + x_out21)
        else:
            x_out = 1 / 2 * (x_out11 + x_out21)
        return self.gamma * x_out + x

if __name__ =='__main__':
    input = torch.randn(1, 256, 7, 7)
    triplet = TripletAttention()
    output = triplet(input)
    print(output.shape)





















#
# class SAM_Module(nn.Module):
#     """ Spatial attention module"""
#
#     # Ref from SAGAN
#     def __init__(self, in_dim):
#         super(SAM_Module, self).__init__()
#         self.chanel_in = in_dim
#
#         self.query_conv = nn.Conv2d(in_channels=in_dim, out_channels=in_dim // 8, kernel_size=1)
#         self.key_conv = nn.Conv2d(in_channels=in_dim, out_channels=in_dim // 8, kernel_size=1)
#         self.value_conv = nn.Conv2d(in_channels=in_dim, out_channels=in_dim, kernel_size=1)
#         self.gamma = nn.Parameter(torch.zeros(1))
#
#         self.softmax = nn.Softmax(dim=-1)
#         self.init_weights()
#
#     def init_weights(self):
#         kaiming_init(self.query_conv)
#         kaiming_init(self.key_conv)
#         kaiming_init(self.value_conv)
#
#     def forward(self, x):
#         """
#             inputs :
#                 x : input feature maps( B X C X H X W)
#             returns :
#                 out : attention value + input feature
#                 attention: B X (HxW) X (HxW)
#         """
#         m_batchsize, C, height, width = x.size()
#         proj_query = self.query_conv(x).view(m_batchsize, -1, width * height).permute(0, 2, 1)
#         proj_key = self.key_conv(x).view(m_batchsize, -1, width * height)
#         energy = torch.bmm(proj_query, proj_key)
#         attention = self.softmax(energy)
#         proj_value = self.value_conv(x).view(m_batchsize, -1, width * height)
#
#         out = torch.bmm(proj_value, attention.permute(0, 2, 1))
#         out = out.view(m_batchsize, C, height, width)
#
#         out = self.gamma * out + x
#         return out


# class CAM_Calculate(nn.Module):
#     """ Channel attention module"""
#
#     def __init__(self, in_dim):
#         super(CAM_Calculate, self).__init__()
#         self.chanel_in = in_dim
#         self.softmax = nn.Softmax(dim=-1)
#
#     def forward(self, x):
#         """
#             inputs :
#                 x : input feature maps( B X C X H X W)
#             returns :
#                 attention: B X C X C
#         """
#         m_batchsize, C, height, width = x.size()
#         proj_query = x.contiguous().view(m_batchsize, C, -1)
#         proj_key = x.contiguous().view(m_batchsize, C, -1).permute(0, 2, 1)
#         energy = torch.bmm(proj_query, proj_key)
#         energy_new = torch.max(energy, -1, keepdim=True)[0].expand_as(energy) - energy
#         attention = self.softmax(energy_new)
#
#         return attention
#
#
# class CAM_Use(nn.Module):
#     """ Channel attention module"""
#
#     def __init__(self, in_dim):
#         super(CAM_Use, self).__init__()
#         self.chanel_in = in_dim
#         self.gamma = nn.Parameter(torch.zeros(1))
#
#     def forward(self, x, attention):
#         """
#             inputs :
#                 x : input feature maps( B X C X H X W)
#                 attention: B X C X C
#             returns :
#                 out : attention value + input feature
#         """
#         m_batchsize, C, height, width = x.size()
#         proj_value = x.contiguous().view(m_batchsize, C, -1)
#         out = torch.bmm(attention, proj_value)
#         out = out.view(m_batchsize, C, height, width)
#         out = self.gamma * out + x
#         return out
#
#
# class _NonLocalBlockND(nn.Module):
#     def __init__(self, in_channels, inter_channels=None, dimension=3, sub_sample=True, bn_layer=True):
#         super(_NonLocalBlockND, self).__init__()
#
#         assert dimension in [1, 2, 3]
#
#         self.dimension = dimension
#         self.sub_sample = sub_sample
#
#         self.in_channels = in_channels
#         self.inter_channels = inter_channels
#
#         if self.inter_channels is None:
#             self.inter_channels = in_channels // 2
#             if self.inter_channels == 0:
#                 self.inter_channels = 1
#
#         if dimension == 3:
#             conv_nd = nn.Conv3d
#             max_pool_layer = nn.MaxPool3d(kernel_size=(1, 2, 2))
#             bn = nn.BatchNorm3d
#         elif dimension == 2:
#             conv_nd = nn.Conv2d
#             max_pool_layer = nn.MaxPool2d(kernel_size=(2, 2))
#             bn = nn.BatchNorm2d
#         else:
#             conv_nd = nn.Conv1d
#             max_pool_layer = nn.MaxPool1d(kernel_size=(2))
#             bn = nn.BatchNorm1d
#
#         self.g = conv_nd(in_channels=self.in_channels, out_channels=self.inter_channels,
#                          kernel_size=1, stride=1, padding=0)
#
#         if bn_layer:
#             self.W = nn.Sequential(
#                 conv_nd(in_channels=self.inter_channels, out_channels=self.in_channels,
#                         kernel_size=1, stride=1, padding=0),
#                 bn(self.in_channels)
#             )
#             nn.init.constant_(self.W[1].weight, 0)
#             nn.init.constant_(self.W[1].bias, 0)
#         else:
#             self.W = conv_nd(in_channels=self.inter_channels, out_channels=self.in_channels,
#                              kernel_size=1, stride=1, padding=0)
#             nn.init.constant_(self.W.weight, 0)
#             nn.init.constant_(self.W.bias, 0)
#
#         self.theta = conv_nd(in_channels=self.in_channels, out_channels=self.inter_channels,
#                              kernel_size=1, stride=1, padding=0)
#         self.phi = conv_nd(in_channels=self.in_channels, out_channels=self.inter_channels,
#                            kernel_size=1, stride=1, padding=0)
#
#         if sub_sample:
#             self.g = nn.Sequential(self.g, max_pool_layer)
#             self.phi = nn.Sequential(self.phi, max_pool_layer)
#
#     def forward(self, x):
#         '''
#         :param x: (b, c, t, h, w)
#         :return:
#         '''
#
#         batch_size = x.size(0)
#
#         g_x = self.g(x).view(batch_size, self.inter_channels, -1)
#         g_x = g_x.permute(0, 2, 1)
#
#         theta_x = self.theta(x).view(batch_size, self.inter_channels, -1)
#         theta_x = theta_x.permute(0, 2, 1)
#         phi_x = self.phi(x).view(batch_size, self.inter_channels, -1)
#         f = torch.matmul(theta_x, phi_x)
#         f_div_C = F.softmax(f, dim=-1)
#
#         y = torch.matmul(f_div_C, g_x)
#         y = y.permute(0, 2, 1).contiguous()
#         y = y.view(batch_size, self.inter_channels, *x.size()[2:])
#         W_y = self.W(y)
#         z = W_y + x
#
#         return z
#
#
# class NONLocalBlock2D(_NonLocalBlockND):
#     def __init__(self, in_channels, inter_channels=None, sub_sample=True, bn_layer=True):
#         super(NONLocalBlock2D, self).__init__(in_channels,
#                                               inter_channels=inter_channels,
#                                               dimension=2, sub_sample=sub_sample,
#                                               bn_layer=bn_layer)
