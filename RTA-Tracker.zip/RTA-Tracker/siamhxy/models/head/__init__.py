from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

from siamban.models.head.ban import UPChannelBAN, DepthwiseBAN, MultiBAN
from siamban.models.head.rpn import UPChannelRPN, DepthwiseRPN, MultiRPN

BANS = {
        'UPChannelBAN': UPChannelBAN,
        'DepthwiseBAN': DepthwiseBAN,
        'MultiBAN': MultiBAN
       }

RPNS = {
        'UPChannelRPN': UPChannelRPN,
        'DepthwiseRPN': DepthwiseRPN,
        'MultiRPN': MultiRPN
       }


def get_ban_head(name, **kwargs):
    return BANS[name](**kwargs)

def get_rpn_head(name, **kwargs):
    return RPNS[name](**kwargs)
