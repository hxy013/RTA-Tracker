# Copyright (c) SenseTime. All Rights Reserved.

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

import torch
import torch.nn as nn
import torch.nn.functional as F
from torchvision.transforms import Resize

from siamban.core.config import cfg
from siamban.models.loss import select_cross_entropy_loss, select_iou_loss
from siamban.models.backbone import get_backbone
from siamban.models.head import get_ban_head
from siamban.models.neck import get_neck
from siamban.models.module.attention import TripletAttention
from siamban.models.module.enhance import SAM_Module
from siamban.core.xcorr import xcorr_depthwise

class ModelBuilder(nn.Module):
    def __init__(self):
        super(ModelBuilder, self).__init__()

        # build backbone
        self.backbone = get_backbone(cfg.BACKBONE.TYPE,
                                     **cfg.BACKBONE.KWARGS)

        # build adjust layer
        if cfg.ADJUST.ADJUST:
            self.neck = get_neck(cfg.ADJUST.TYPE,
                                 **cfg.ADJUST.KWARGS)

        # build enhance module
        self.enhance = SAM_Module(256)

        # build attention module
        self.attention = TripletAttention()
        # build ban head
        if cfg.BAN.BAN:
            self.head = get_ban_head(cfg.BAN.TYPE,
                                     **cfg.BAN.KWARGS)


    def template(self, z):
        zf = self.backbone(z)
        if cfg.ADJUST.ADJUST:
            zf = self.neck(zf)
        self.zf = zf

    def convert_bbox(self, delta, anchors):
        batch_size = delta.shape[0]
        delta = delta.view(batch_size, 4, -1)
        anchors = anchors.view(4, -1).permute(1, 0).contiguous()
        output_boxes = torch.zeros(batch_size, 4, delta.shape[2])
        for i in range (batch_size):
           output_boxes[i][0, :] = delta[i][0, :] * anchors[:, 2] + anchors[:, 0]
           output_boxes[i][1, :] = delta[i][1, :] * anchors[:, 3] + anchors[:, 1]
           output_boxes[i][2, :] = torch.exp(delta[i][2, :]) * anchors[:, 2]
           output_boxes[i][3, :] = torch.exp(delta[i][3, :]) * anchors[:, 3]
        return output_boxes

    def track(self, x):
        xf = self.backbone(x)
        if cfg.ADJUST.ADJUST:
            xf = self.neck(xf)

        cls, loc = self.head(self.zf, xf)
        # cls, loc = self.rpn_head(cls, loc)
        return {
                'cls': cls,
                'loc': loc
               }


    def log_softmax(self, cls):
        if cfg.BAN.BAN:
            cls = cls.permute(0, 2, 3, 1).contiguous()
            cls = F.log_softmax(cls, dim=3)
        return cls

    def forward(self, data):
        """ only used in training
        """
        template = data['template'].cuda()
        search = data['search'].cuda()
        label_cls = data['label_cls'].cuda()
        label_loc = data['label_loc'].cuda()

        # get feature
        zf = self.backbone(template)
        xf = self.backbone(search)
        if cfg.ADJUST.ADJUST:
            zf = self.neck(zf)
            xf = self.neck(xf)

        for i in range(len(xf) - 1):
            zf[i] = self.enhance(zf[i])
            xf[i] = self.enhance(xf[i])

        for i in range(len(xf) - 1):
            zf[i] = self.attention(zf[i])
            xf[i] = self.attention(xf[i])

        cls, loc = self.head(zf, xf)


        # get loss

        # cls loss with cross entropy loss
        cls = self.log_softmax(cls)
        cls_loss = select_cross_entropy_loss(cls, label_cls)

        # loc loss with iou loss
        loc_loss = select_iou_loss(loc, label_loc, label_cls)

        outputs = {}
        outputs['total_loss'] = cfg.TRAIN.CLS_WEIGHT * cls_loss + \
                                cfg.TRAIN.LOC_WEIGHT * loc_loss
        outputs['cls_loss'] = cls_loss
        outputs['loc_loss'] = loc_loss

        return outputs


# if __name__ == '__main__':
#     backbone = get_backbone('resnet50', used_layers=[2, 3, 4])
#     #backbone = ModelBuilder().backbone(name='resnet50', used_layers=[2,3,4])
#     z = torch.randn(1, 3, 127, 127)
#     x = torch.randn(1, 3, 255, 255)
#     zf = backbone(z)
#     xf = backbone(x)
#     for i in range(len(zf)):
#         print(zf[i].shape)
#         print(xf[i].shape)
#     # build.head()
#     neck = get_neck('AdjustAllLayer', [512, 256])